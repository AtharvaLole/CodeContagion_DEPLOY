

# Realistic CodeContagion Landing Page Upgrade

## What Changes

### 1. Realistic Earth with NASA Textures
Replace the plain dark sphere with a photorealistic Earth using free NASA texture maps loaded via `useTexture` from drei:
- Day map (color), bump map (terrain elevation), specular map (ocean shine), cloud layer (semi-transparent rotating overlay)
- Texture URLs from publicly available NASA/solar system scope CDNs (e.g. `unpkg.com/three-globe/example/img/earth-*.jpg` or similar free CDN-hosted textures)
- Atmosphere shader stays but gets tuned for realism (blue Fresnel glow matching real atmosphere)

### 2. More Realistic Robot/Virus Creature
Upgrade from basic octahedron to a menacing multi-part mechanical virus:
- Central icosahedron core with animated pulsing emissive glow
- Multiple articulated "legs" / tentacles made from chained cylinders with animated joint rotations
- Floating spike protrusions that extend outward
- Particle trail behind it as it moves (small red/purple sparks)
- Glitch/distortion aura — a transparent shell with animated noise displacement
- Eye-like glowing red sphere in the center
- Overall scale larger and more threatening

### 3. Infection Visualization Upgrade
- Nodes pulse with a red glow ripple when infected
- Connection lines animate with a "traveling pulse" effect (shader or animated dash offset) showing infection moving along edges
- Infected nodes emit small particle bursts periodically

### 4. Post-Destruction Flow: Warp + Homepage Redirect
- After robot explodes, warp animation plays for ~2.5 seconds
- Then navigate to a new `/home` route — a clean, dark, cinematic page with:
  - Large "CODE CONTAGION" title with glow
  - Subtle particle background
  - "Mission Unlocked" subtitle
  - Simple CTA buttons (placeholder)

### 5. Enhanced Space Background
- Higher star count and depth
- Subtle nebula color tinting via background CSS gradient layers
- Slow-drifting larger dust particles with slight color variation

## Files to Create/Modify

| File | Action |
|------|--------|
| `src/components/landing/Earth.tsx` | Rewrite — NASA textures, cloud layer, better atmosphere |
| `src/components/landing/RobotCreature.tsx` | Rewrite — multi-part mechanical virus with tentacles, particle trail |
| `src/components/landing/NetworkNodes.tsx` | Enhance — traveling pulse on edges, particle bursts on infected nodes |
| `src/components/landing/SpaceScene.tsx` | Minor tweaks — better lighting, nebula dust |
| `src/components/landing/HUDOverlay.tsx` | Minor — remove "MISSION COMPLETE" state (replaced by navigation) |
| `src/routes/index.tsx` | Add navigation to `/home` after destruction |
| `src/routes/home.tsx` | **Create** — cinematic homepage with CodeContagion branding |
| `src/components/landing/Explosion.tsx` | Enhance — more particles, shockwave ring |
| `src/styles.css` | Add any new keyframes needed |

## Technical Notes
- Earth textures: Use free CDN-hosted NASA images (no Blender needed — procedural textures + high-res maps achieve the same realism in WebGL)
- Blender `.glb` models are possible but add significant bundle size and loading time; procedural geometry with good materials will look better for this use case at web scale
- Navigation uses TanStack Router's `useNavigate` hook
- All new texture URLs are from public CDNs (no API keys needed)

