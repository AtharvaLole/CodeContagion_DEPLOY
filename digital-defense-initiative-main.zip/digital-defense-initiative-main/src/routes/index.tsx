import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect, useCallback } from "react";
import SpaceScene from "@/components/landing/SpaceScene";
import HUDOverlay from "@/components/landing/HUDOverlay";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "CodeContagion — Neutralize the Digital Infection" },
      {
        name: "description",
        content:
          "A gamified AI simulation platform battling software bugs and misinformation. Enter the mission.",
      },
    ],
  }),
});

function Index() {
  const [loading, setLoading] = useState(true);
  const [destroyed, setDestroyed] = useState(false);
  const [fadeToBlack, setFadeToBlack] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2500);
    return () => clearTimeout(timer);
  }, []);

  // Warp sequence: explosion → warp lines → fade to black → navigate
  useEffect(() => {
    if (!destroyed) return;
    // Fade to black after warp builds up
    const fadeTimer = setTimeout(() => setFadeToBlack(true), 2000);
    // Navigate after full blackout
    const navTimer = setTimeout(() => {
      navigate({ to: "/home" });
    }, 3200);
    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(navTimer);
    };
  }, [destroyed, navigate]);

  const handleDestroy = useCallback(() => setDestroyed(true), []);

  return (
    <div className="relative w-screen h-screen overflow-hidden"
      style={{ background: "radial-gradient(ellipse at center, #0a1628 0%, #050510 50%, #000005 100%)" }}>

      {!loading && (
        <SpaceScene
          onDestroy={handleDestroy}
          destroyed={destroyed}
        />
      )}

      <HUDOverlay destroyed={destroyed} loading={loading} />

      {/* Fade to black overlay for warp-to-void transition */}
      {fadeToBlack && (
        <div
          className="fixed inset-0 z-50 pointer-events-none"
          style={{
            background: "#000000",
            animation: "fade-to-black 1.2s ease-in forwards",
          }}
        />
      )}
    </div>
  );
}
