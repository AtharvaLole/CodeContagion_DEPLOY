import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useEffect, useRef } from "react";

export const Route = createFileRoute("/home")({
  component: HomePage,
  head: () => ({
    meta: [
      { title: "CodeContagion — Mission Control" },
      { name: "description", content: "Welcome to CodeContagion. The infection has been neutralized. Your mission begins now." },
    ],
  }),
});

function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: { x: number; y: number; vx: number; vy: number; size: number; opacity: number }[] = [];
    for (let i = 0; i < 150; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 2 + 0.5,
        opacity: Math.random() * 0.5 + 0.1,
      });
    }

    let animId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(0, 240, 255, ${p.opacity})`;
        ctx.fill();
      });
      animId = requestAnimationFrame(animate);
    };
    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 z-0" />;
}

function HomePage() {
  return (
    <div
      className="relative w-screen h-screen overflow-hidden flex items-center justify-center font-mono"
      style={{ background: "radial-gradient(ellipse at center, #0a1628 0%, #050510 50%, #000005 100%)" }}
    >
      <ParticleCanvas />

      {/* Scanline */}
      <div className="fixed inset-0 pointer-events-none z-10 scanline-overlay" />

      <div className="relative z-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="text-xs tracking-[0.5em] mb-6"
          style={{ color: "#00ff88" }}
        >
          INFECTION NEUTRALIZED // MISSION UNLOCKED
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.6, type: "spring", damping: 12 }}
          className="text-5xl md:text-7xl font-bold tracking-[0.15em] mb-2"
          style={{
            color: "#00f0ff",
            textShadow: "0 0 40px #00f0ff60, 0 0 80px #00f0ff30, 0 0 120px #00f0ff15",
          }}
        >
          CODE
        </motion.h1>
        <motion.h1
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, delay: 0.8, type: "spring", damping: 12 }}
          className="text-5xl md:text-7xl font-bold tracking-[0.15em] mb-8"
          style={{
            color: "#ff1744",
            textShadow: "0 0 40px #ff174460, 0 0 80px #ff174430, 0 0 120px #ff174415",
          }}
        >
          CONTAGION
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="text-sm tracking-[0.3em] mb-12"
          style={{ color: "#ffffff40" }}
        >
          GAMIFIED AI SIMULATION // DIGITAL DEFENSE PLATFORM
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.6 }}
          className="flex gap-6 justify-center"
        >
          <button
            className="px-8 py-3 text-sm tracking-[0.2em] font-mono border transition-all duration-300 hover:scale-105"
            style={{
              borderColor: "#00f0ff40",
              color: "#00f0ff",
              background: "rgba(0, 240, 255, 0.05)",
              boxShadow: "0 0 20px rgba(0, 240, 255, 0.1)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "rgba(0, 240, 255, 0.15)";
              e.currentTarget.style.boxShadow = "0 0 30px rgba(0, 240, 255, 0.3)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "rgba(0, 240, 255, 0.05)";
              e.currentTarget.style.boxShadow = "0 0 20px rgba(0, 240, 255, 0.1)";
            }}
          >
            ENTER SIMULATION →
          </button>
        </motion.div>
      </div>
    </div>
  );
}
